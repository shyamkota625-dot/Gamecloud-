const games=[
 {id:"gta5",name:"GTA V",genre:"Action • Open World",image:"images/gta-v.jpg",emoji:"🚗"},
 {id:"rdr1",name:"Red Dead Redemption 1",genre:"Action • Adventure",image:"images/red-dead-redemption.jpg",emoji:"🤠"},
 {id:"rdr2",name:"Red Dead Redemption 2",genre:"Action • Open World",image:"images/red-dead-redemption-2.jpg",emoji:"🐎"},
 {id:"hff",name:"Human Fall Flat",genre:"Puzzle • Platformer",emoji:"🧩"},
 {id:"cricket24",name:"Cricket 24",genre:"Sports • Cricket",emoji:"🏏"}
];
const grid=document.querySelector("#gamesGrid"), search=document.querySelector("#search"), library=document.querySelector("#libraryList");
const key="gamecloud-library";
const saved=()=>JSON.parse(localStorage.getItem(key)||"[]");
function renderGames(list=games){
 grid.innerHTML=list.map(g=>`<article class="game"><div class="game-art">${g.image?`<img src="${g.image}" alt="${g.name} cover">`:`<div class="emoji">${g.emoji}</div>`}</div><div class="game-info"><h3>${g.name}</h3><small>${g.genre}</small><div class="game-actions"><button onclick="playGame('${g.name}')">Play demo</button><button onclick="saveGame('${g.id}')">Save</button></div></div></article>`).join("")||"<p class='muted'>No games found.</p>";
}
function renderLibrary(){
 const ids=saved(), items=games.filter(g=>ids.includes(g.id));
 library.innerHTML=items.length?items.map(g=>`<div class="saved"><strong>${g.name}</strong><button onclick="removeGame('${g.id}')">Remove</button></div>`).join(""):"<p class='muted'>No games saved yet. Tap “Save” on a game above.</p>";
}
function saveGame(id){const a=saved();if(!a.includes(id)){a.push(id);localStorage.setItem(key,JSON.stringify(a));renderLibrary()}}
function removeGame(id){localStorage.setItem(key,JSON.stringify(saved().filter(x=>x!==id)));renderLibrary()}
function playGame(name){alert(`${name}: demo button only. Full commercial game play requires the game to be legitimately installed or provided by a licensed service.`)}
search.addEventListener("input",e=>{const q=e.target.value.toLowerCase();renderGames(games.filter(g=>(g.name+" "+g.genre).toLowerCase().includes(q)))});
renderGames();renderLibrary();
